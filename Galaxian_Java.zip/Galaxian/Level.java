package galaxians;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Level extends JPanel implements KeyListener{
	
	JFrame window = new JFrame();
	OurCraft oc = new OurCraft(576,620,"Images//ourcraft.png");
	EnemyCraft ec[][] = new EnemyCraft[2][15];
	int xAxis=0,yAxis=0;
	Bullets bullet[] = new Bullets[35] ;
	Drop drop = new Drop(this,ec);
	int count=0,shown=0;
	
	Level()
	{
		this.setFocusable(true);
		this.addKeyListener(this);
		window.add(this);
		
		for(int i=0;i<ec.length;i++)
		{
			for(int j=0;j<ec[i].length;j++)
			{
				ec[i][j] = new EnemyCraft(xAxis,yAxis,"Images//enemycraft.png");	
				xAxis += 85;
			}
			yAxis += 50;
			xAxis = 0;
		}
		
		drop.start();
		
		for(int i=0;i<bullet.length;i++)
		{
			bullet[i] = new Bullets(oc.getxAxis(),oc.getyAxis()+60,"Images//bullet.png");
	    }
		
		window.setSize(1280,720);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//closes when exited
		window.setVisible(true);
	}
	
	public void paint(Graphics g)
	{
		ImageIcon background = new ImageIcon("Images//background.jpg");//importing image
		g.drawImage(background.getImage(),0,0,null);//painting background	
		
		oc.drawOurCraft(g);
		
		
		for(int i =0;i<bullet.length;i++)
		{
			bullet[i].drawBullets(g);
		}
		
		for(int i=0;i<ec.length;i++)
		{
			for(int j=0;j<ec[i].length;j++)
			{
				ec[i][j].drawEnemyCraft(g);
			}
		}
		
		g.setColor(Color.WHITE);
		g.setFont(new Font("",Font.BOLD,22));
		g.drawString("SCORE = "+Fire.score, 10, 20);
		g.drawString("BULLETS LEFT = "+(35-count), 1000, 20);
		levelFailed();
		levelComplete();
	}
	
	public void levelComplete()
	{
		if(Fire.score==300 && shown == 0)
		{
			try
			{   //block to add sound
				File shootSound = new File("Sounds//gamewon.wav");
				AudioInputStream ais = AudioSystem.getAudioInputStream(shootSound);
				Clip clip = AudioSystem.getClip();
				clip.open(ais);
				clip.start();
				
			}catch(Exception e)
			{
				System.out.println(e);
			}
			shown++;
			drop.stop();
			JOptionPane.showMessageDialog(null, "Congratualitons!!!You have defended your base!");
		}
		
	}
	
	public void levelFailed()
	{
		for(int i=0;i<ec.length;i++)
		{
			for(int j=0;j<ec[i].length;j++)
			{
				if(ec[i][j].getyAxis()>600 && shown == 0)
				{
					try
					{   //block to add sound
						File shootSound = new File("Sounds//gamelost.wav");
						AudioInputStream ais = AudioSystem.getAudioInputStream(shootSound);
						Clip clip = AudioSystem.getClip();
						clip.open(ais);
						clip.start();
						
					}catch(Exception e)
					{
						System.out.println(e);
					}
					shown++;
					drop.stop();
					JOptionPane.showMessageDialog(null,"Game Over!!!The Invaders have reached your base!\nSCORE = "+Fire.score+"/300");
					break; 
				}
			}
		}
		
		if(count==35 && shown==0)
		{
			try
			{   //block to add sound
				File shootSound = new File("Sounds//gamelost.wav");
				AudioInputStream ais = AudioSystem.getAudioInputStream(shootSound);
				Clip clip = AudioSystem.getClip();
				clip.open(ais);
				clip.start();
				
			}catch(Exception e)
			{
				System.out.println(e);
			}
			shown++;
			drop.stop();
			JOptionPane.showMessageDialog(null,"Game Over!!!You have ran out of bullets!\nSCORE = "+Fire.score+"/300");
		}
	}
	
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent kp) {
		if(kp.getKeyCode()==KeyEvent.VK_RIGHT|| kp.getKeyCode()==KeyEvent.VK_D)
		{
			if(oc.getxAxis()<1215)
				oc.setxAxis(oc.getxAxis()+10);
			this.repaint();
		}
		else if(kp.getKeyCode()==KeyEvent.VK_LEFT||kp.getKeyCode()==KeyEvent.VK_A)
		{
			if(oc.getxAxis()>0)
				oc.setxAxis(oc.getxAxis()-10);
			this.repaint();
		}
		else if(kp.getKeyCode()==KeyEvent.VK_SPACE || kp.getKeyCode() == KeyEvent.VK_S)
		{
			try
			{
				File shootSound = new File("Sounds//shoot.wav");
				AudioInputStream ais = AudioSystem.getAudioInputStream(shootSound);
				Clip clip = AudioSystem.getClip();
				clip.open(ais);
				clip.start();
				
			}catch(Exception e)
			{
				System.out.println(e);
			}
			Fire f = new Fire(bullet[count],this,ec);
			bullet[count].setxAxis(oc.getxAxis());
			bullet[count].setyAxis(oc.getyAxis());
			f.start();
			count++;
		}
		
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

}
