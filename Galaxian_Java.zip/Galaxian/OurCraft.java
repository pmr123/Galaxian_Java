package galaxians;

import java.awt.Graphics;

import javax.swing.ImageIcon;

public class OurCraft {
	private int xAxis,yAxis;
	private String imagePath;
	public OurCraft(int xAxis, int yAxis, String imagePath) {
		super();
		this.xAxis = xAxis;
		this.yAxis = yAxis;
		this.imagePath = imagePath;
	}
	public int getxAxis() {
		return xAxis;
	}
	public void setxAxis(int xAxis) {
		this.xAxis = xAxis;
	}
	public int getyAxis() {
		return yAxis;
	}
	public void setyAxis(int yAxis) {
		this.yAxis = yAxis;
	}
	public String getImagePath() {
		return imagePath;
	}
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	public void drawOurCraft(Graphics g)
	{
		ImageIcon ourcraft = new ImageIcon(imagePath);
		g.drawImage(ourcraft.getImage(), xAxis, yAxis, null);
	}
	
}
