package galaxians;

import java.awt.Graphics;

import javax.swing.ImageIcon;

public class Bullets {
	private int xAxis,yAxis;
	private String imagePath;
	public Bullets(int xAxis, int yAxis, String imagePath) {
		super();
		this.xAxis = xAxis;
		this.yAxis = yAxis;
		this.imagePath = imagePath;
	}
	public int getxAxis() {
		return xAxis;
	}
	public void setxAxis(int xAxis) {
		this.xAxis = xAxis;
	}
	public int getyAxis() {
		return yAxis;
	}
	public void setyAxis(int yAxis) {
		this.yAxis = yAxis;
	}
	public String getImagePath() {
		return imagePath;
	}
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	public void drawBullets(Graphics g)
	{
		ImageIcon enemycraft = new ImageIcon(imagePath);
		g.drawImage(enemycraft.getImage(), xAxis, yAxis, null);
	}

}
