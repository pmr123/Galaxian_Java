package galaxians;

public class MainOfGame {

	public static void main(String args[]) {
		OpeningWindow ow = new OpeningWindow();//calling openingwindow

	}

}
