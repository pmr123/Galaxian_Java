package galaxians;

import java.awt.Rectangle;
import java.io.File;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class Fire extends Thread{
	
	Bullets bullet;
	Level l;
	EnemyCraft ec[][];
	public static int score=0;
	
	Fire(Bullets bullet,Level l,EnemyCraft ec[][])
	{
		this.bullet = bullet;
		this.l = l;
		this.ec = ec;
		
	}
	
	@Override
	public void run()
	{
		while(bullet.getyAxis()>-100)
		{
			bullet.setyAxis(bullet.getyAxis()-10);
			checkCollision();
			
			try {
				Thread.sleep(10);//to slow down bullet
			} catch (InterruptedException e) {
				System.out.println(e);
			}
			l.repaint();
		}
		
	}
	public void checkCollision()
	{
		Rectangle bulletRect = new Rectangle(bullet.getxAxis(),bullet.getyAxis(),50,50);
		
		for(int i=0;i<ec.length;i++)
		{
			for(int j=0;j<ec[i].length;j++)
			{
				Rectangle ecRect = new Rectangle(ec[i][j].getxAxis(),ec[i][j].getyAxis(),50,50);
				if(bulletRect.intersects(ecRect))
				{
					ec[i][j].setxAxis(5000);
					bullet.setxAxis(-5000);
					score+=10;
					try
					{
						File shootSound = new File("Sounds//enemykilled.wav");
						AudioInputStream ais = AudioSystem.getAudioInputStream(shootSound);
						Clip clip = AudioSystem.getClip();
						clip.open(ais);
						clip.start();
						
					}catch(Exception e)
					{
						System.out.println(e);
					}
				}
			}
		}
	}

}
