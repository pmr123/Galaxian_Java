package galaxians;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class OpeningWindow extends JPanel implements ActionListener,KeyListener{
	JFrame window = new JFrame();
	JButton playbutton = new JButton();
	JButton exitbutton = new JButton();
	JLabel welcomeLabel = new JLabel();
	OpeningWindow()
	{
		window.add(this);//adds panel
		
		try
		{   //block to add sound
			File shootSound = new File("Sounds//Start.wav");
			AudioInputStream ais = AudioSystem.getAudioInputStream(shootSound);
			Clip clip = AudioSystem.getClip();
			clip.open(ais);
			clip.start();
			
		}catch(Exception e)
		{
			System.out.println(e);
		}
		
		playbutton.setBackground(Color.BLACK);   
		playbutton.setForeground(Color.WHITE);
		playbutton.setVerticalTextPosition(SwingConstants.BOTTOM);
		playbutton.setHorizontalTextPosition(SwingConstants.CENTER);
		playbutton.setIcon(new ImageIcon("Images//playButton.png"));//adds image to playButton
		playbutton.addActionListener(this);
		playbutton.addKeyListener(this);
		playbutton.setText("PLAY");
		window.add(playbutton,BorderLayout.WEST);//adds playbutton to window
		
		exitbutton.setBackground(Color.BLACK);   
		exitbutton.setForeground(Color.WHITE);
		exitbutton.setVerticalTextPosition(SwingConstants.BOTTOM);
		exitbutton.setHorizontalTextPosition(SwingConstants.CENTER);
		exitbutton.setIcon(new ImageIcon("Images//exitButton.png"));//adds image to playButton
		exitbutton.addActionListener(this);
		exitbutton.addKeyListener(this);
		exitbutton.setText("EXIT");
		window.add(exitbutton,BorderLayout.EAST);//adds exit button to window
		
		
		welcomeLabel.setText("Press space or s to shoot and move with arrow keys or a and d.Be Carefull, You Only have 35 Bullets");
		welcomeLabel.setOpaque(true);
		welcomeLabel.setBackground(Color.BLACK);
		welcomeLabel.setForeground(Color.RED);
		window.add(welcomeLabel,BorderLayout.NORTH);//adds welcomeLabel to window
		
		window.setSize(1580,690);//sets size of panel
		window.setUndecorated(true);//hides the title bar
		window.setVisible(true);//makes the window visible	
	}
	
	public void paint(Graphics g)
	{
		ImageIcon background = new ImageIcon("Images//IntroBackground.png");//importing image
		g.drawImage(background.getImage(),0,0,null);//painting background	
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent kp) {
		if(kp.getKeyCode()==kp.VK_ESCAPE)
		{
			window.dispose();//disposes the window
		}
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		if(ae.getSource()==exitbutton)
		{
			window.dispose();//disposes the window
		}
		if(ae.getSource()==playbutton)
		{
			window.dispose();//disposes current window
			Level l = new Level();//calls level window
		}
	}
}
