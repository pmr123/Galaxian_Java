package galaxians;

public class Drop extends Thread{
	Level l;
	EnemyCraft ec[][];
	
	Drop(Level l, EnemyCraft ec[][])
	{
		this.l=l;
		this.ec=ec;
	}
	
	public void run()
	{
		while(ec[1][0].getyAxis()<610)
		{
			for(int i =0;i<ec.length;i++)
			{
				for(int j=0;j<ec[i].length;j++)
				{
					ec[i][j].setyAxis(ec[i][j].getyAxis()+20);
				}			
			}
			
			try {
				Thread.sleep(900);
			} catch (InterruptedException e) {
				System.out.println(e);
			}
			l.repaint();
		}
	}
}
